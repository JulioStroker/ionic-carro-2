<a name"0.6.0"></a>
## 0.6.0 (2016-03-06)


#### Bug Fixes

* **bower.json:** fix bower main script config ([884884ee](https://github.com/the-darc/angular-br-filters/commit/884884ee))


#### Features

* **age:** add filter 'age' to calculate the age based on the birthdate ([0884d523](https://github.com/the-darc/angular-br-filters/commit/0884d523))


<a name"0.5.0"></a>
## 0.5.0 (2015-09-01)


#### Features

* **browserify:** refactor to use common-js and allow browserify ([dcac96cd](https://github.com/the-darc/angular-br-filters/commit/dcac96cd))


<a name"0.4.0"></a>
## 0.4.0 (2015-05-15)


#### Features

* **brCpfCnpj:** new filter brCpfCnpj (resolve #2) ([7d8e4f28](https://github.com/the-darc/angular-br-filters/commit/7d8e4f28))


<a name"0.3.1"></a>
### 0.3.1 (2015-05-15)

